#ifndef WEBDATA_SHM_H_
#define WEBDATA_SHM_H_

#include <WString.h>

struct webDataSHM {
    String data = "";
    int contentLength = 0;
    
};

#endif /* WEBDATA_SHM_H_ */
