#ifndef UTILITIES_H_
#define UTILITIES_H_

void blockMotorStart(int pPinINH);

#endif
